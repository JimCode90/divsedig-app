/*
Template Name: Morvin -  Admin & Dashboard Template
Author: Themesdesign
Contact: themesdesign.in@gmail.com
File: Form Mosk
*/


$(document).ready(function(){
    $(".input-mask").inputmask();
});