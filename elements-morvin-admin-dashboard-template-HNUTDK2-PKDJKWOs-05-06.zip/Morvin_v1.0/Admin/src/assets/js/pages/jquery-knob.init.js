/*
Template Name: Morvin -  Admin & Dashboard Template
Author: Themesdesign
Contact: themesdesign.in@gmail.com
File: Jquery Knob
*/


$(function () {
    $('[data-plugin="knob"]').knob();
  });