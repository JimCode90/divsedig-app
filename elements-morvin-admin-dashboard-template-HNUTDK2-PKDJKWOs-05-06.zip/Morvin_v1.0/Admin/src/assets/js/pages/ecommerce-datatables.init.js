/*
Template Name: Morvin -  Admin & Dashboard Template
Author: Themesdesign
Contact: themesdesign.in@gmail.com
File: Ecommerce Datatables
*/


// datatable
$(document).ready(function() {
    $('.datatable').DataTable();
     $(".dataTables_length select").addClass('form-select form-select-sm');
});